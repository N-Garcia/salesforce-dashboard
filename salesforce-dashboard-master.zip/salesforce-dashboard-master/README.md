## Brief Overview
This is a proof-of-concept app for creating customizable dashboards on top of Salesforce via API. The general idea is that this can be used to avoid lead times for customization and the need for specialized Salesforce developers.

## Things to note
You will need to signup for a Salesforce Developers account here: https://developer.salesforce.com/signup?d=70130000000td6N, and configure the appropriate connection variables in order to pull the dummy data in from Salesforce and test the functionality of the app. 