import React, { Component } from 'react';


class UpdateCase extends Component {


  render() {
    return (
         <div className="row">
              <div className="col-sm-8">
                   <h1>
                    Update Case
                   </h1>
               </div>
         </div>
    );
  }
}

export default UpdateCase;
